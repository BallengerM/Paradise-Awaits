﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParadiseAwaits;

namespace GameTests
{
    [TestClass]
    public class UnitTest1
    {

    }
}
