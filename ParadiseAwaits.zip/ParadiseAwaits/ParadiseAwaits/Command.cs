﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    public class Command
    {
        private String commandWord;
        private String secondWord;

        public Command(string firstWord, string secondWord)
        {
            commandWord = firstWord;
            this.secondWord = secondWord;
        }

        public string getCommandWord()
        {
            return commandWord;
        }

        public string getSecondWord()
        {
            return secondWord;
        }

        public Boolean commandUnknown()
        {
            return (commandWord == null);
        }

        public Boolean hasSecondWord()
        {
            return (secondWord != null);
        }
    }
}
