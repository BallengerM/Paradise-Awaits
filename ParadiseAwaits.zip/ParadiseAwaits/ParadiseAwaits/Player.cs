﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    public class Player
    {
        private static ArrayList playerInventory;

        public Player()
        {
            playerInventory = new ArrayList();
        }

        public string addItem(string item)
        {
            if (playerInventory.Contains(item) == false)
            {
                playerInventory.Add(item);
                return "Taken.";
            }
            else
            {
                return "You already have that item.";
            }
        }

        public string dropItem(string item)
        {
            if(playerInventory.Contains(item) == true)
            {
                playerInventory.Remove(item);
                return "Dropped.";
            }
            else
            {
                return "You do not have that item";
            }
        }

        public void showInventory()
        {
            foreach (string item in playerInventory)
            {
                Console.WriteLine(item);
            }
        }

        public bool inventoryContains(string item)
        {
            if(playerInventory.Contains(item) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
