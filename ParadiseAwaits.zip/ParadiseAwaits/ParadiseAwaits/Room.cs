﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    
    public class Room
    {
        //room attributes
        private string[] description;
        private Dictionary<string, Room> roomExits;
        private ArrayList roomInventory;

        public Room(string descriptionFile, string fileLocation)
        {
            description = System.IO.File.ReadAllLines(descriptionFile);
            roomExits = new Dictionary<string, Room>();
            roomInventory = new ArrayList();
            string[] roomFile = System.IO.File.ReadAllLines(fileLocation);
            foreach (string item in roomFile)
            {
                roomInventory.Add(item);
            }
        }

        public void setExit(string direction, Room neighbor)
        {
            roomExits.Add(direction, neighbor);
        }

        /*public string roomName()
        {
            return description;
        }

        public string roomDescription()
        {
            return "You are " + description + ".\n" + getExits() + "\n" + getItems();
        }
        */

        public string[] roomDescription()
        {
            return description;
        }

        private string getExits()
        {
            string exits = "Exits: ";
            foreach (string key in roomExits.Keys)
            {
                exits += key;
                exits += ' ';
            }
            return exits;
        }

        private string getItems()
        {
            string items = "These items are available here: ";
            foreach(string item in roomInventory)
            {
                items += "\n";
                items += item;
            }
            return items;
        }

        public bool checkItems(string itemName)
        {
            string fourItem = "";
            string fourList = "";

            for (int i = 0; i < 3; i++)
            {
                fourItem += itemName[i];
            }

            foreach (string item in roomInventory)
            {
                for(int j=0; j < 3; j++)
                {
                    fourList += item[j];
                }

                if(fourItem == fourList)
                {
                    return true;
                }
            }
            return false;
        }

        public Room getExitRoom(string direction)
        {
            return roomExits[direction];
        }
    }
}
