﻿/*
Makayla Ballenger
Senior Project
References:
https://docs.microsoft.com/en-us/dotnet/csharp/how-to/parse-strings-using-split
zuul chapter 6 for game structure
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    class ParadiseAwaits
    {

        static void Main(string[] args)
        {
            Game_Main game = new Game_Main();
            game.Play();
        }
    }
}
