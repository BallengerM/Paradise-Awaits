﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    public class Game_Main
    {
        private Parser parser;
        private Room currentRoom;
        private Player player;

        public Game_Main()
        {
            createRooms();
            parser = new Parser();
            player = new Player();
        }

        private void createRooms()
        {
            Room start = new Room("startDescription.txt","startItems.txt");
            Room frontOfCabin = new Room("frontofcabinDescription.txt","frontofcabinItems.txt");
            Room insideTheCabin = new Room("insidethecabinDescription.txt","insidethecabinItems.txt");
            Room backOfCabin = new Room("backofcabinDescription.txt","backofcabinItems.txt");
            Room forestPath = new Room("forestpathDescription.txt","forestpathItems.txt");
            Room bearDen = new Room("beardenDescription.txt","beardenItems.txt");
            Room cave = new Room("caveDescription.txt","caveItems.txt");
            Room eastPassage = new Room("eastpassageDescription.txt","eastpassageItems.txt");
            Room skiLodge = new Room("skilodgeDescription.txt","skilodgeItems.txt");
            Room topOfMtn = new Room("topofmtnDescription.txt","topofmtnItems.txt");
            Room northPassage = new Room("northpassageDescription.txt","northpassageItems.txt");
            Room placeOfWorship = new Room("placeofworshipDescription.txt","placeofworshipItems.txt");
            Room heaven = new Room("heavenDescription.txt","heavenItems.txt");
            Room westPassage = new Room("westpassageDescription.txt","westpassageItems.txt");
            Room deadEnd = new Room("deadendDescription.txt", "deadendItems.txt");
            Room beach = new Room("beachDescription.txt", "beachItems.txt");
            Room pier = new Room("pierDescription.txt", "pierItems.txt");
            Room maze = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze1 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze2 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze3 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze4 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze5 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room maze6 = new Room("mazeDescription.txt", "mazeItems.txt");
            Room treasureRoom = new Room("treasureroomDescription.txt", "treasureroomItems.txt");
            
            //start exits
            start.setExit("north", frontOfCabin);

            //frontOfCabin exits
            frontOfCabin.setExit("north", insideTheCabin);

            //insideTheCabin exits
            insideTheCabin.setExit("south", frontOfCabin);
            insideTheCabin.setExit("north", backOfCabin);
            

            //backOfCabin exits
            backOfCabin.setExit("west", forestPath);
            backOfCabin.setExit("south", insideTheCabin);

            //forestPath exits
            forestPath.setExit("east", backOfCabin);
            forestPath.setExit("north", bearDen);

            
            //bearDen exits
            bearDen.setExit("south", forestPath);
            bearDen.setExit("north", cave);
            
            //cave exits
            cave.setExit("south", bearDen);
            cave.setExit("west", westPassage);
            cave.setExit("east", eastPassage);
            cave.setExit("north", northPassage);

            //eastPassage exits
            eastPassage.setExit("west", cave);
            eastPassage.setExit("east", skiLodge);

            //skiLodge exits
            skiLodge.setExit("west", eastPassage);
            skiLodge.setExit("up", topOfMtn);

            //topOfMtn exits
            topOfMtn.setExit("down", backOfCabin);

            //northPassage exits
            northPassage.setExit("south", cave);
            northPassage.setExit("north", placeOfWorship);

            //placeOfWorship exits
            placeOfWorship.setExit("pray", heaven);

            //westPassage exits
            westPassage.setExit("east", cave);
            westPassage.setExit("west", deadEnd);

            //beach exits
            beach.setExit("west", pier);

            //pier exits
            pier.setExit("east", beach);
            pier.setExit("west", maze);

            //maze exits
            maze.setExit("east", pier);
            maze.setExit("west", maze1);

            //maze1 exits
            maze1.setExit("north", maze1);
            maze1.setExit("west", maze1);
            maze1.setExit("east", maze);
            maze1.setExit("south", maze2);

            //maze2 exits
            maze2.setExit("north", maze1);
            maze2.setExit("west", maze3);

            //maze3 exits
            maze3.setExit("east", maze2);
            maze3.setExit("west", maze4);
            maze3.setExit("southeast", maze5);

            //maze4 exits
            maze4.setExit("east", maze3);

            //maze5 exits
            maze5.setExit("northwest", maze3);
            maze5.setExit("south", maze5);
            maze5.setExit("east", maze6);

            //maze6 exits
            maze6.setExit("west", maze5);
            maze6.setExit("north", treasureRoom);
            
            currentRoom = start;
        }

        public void Play()
        {
            printWelcome();

            Boolean finish = false;
            while(finish != true)
            {
                Command command = parser.getCommand();
                finish = processCommand(command);
            }
            Console.WriteLine("Paradise awaited your arrival. Thank you for playing.");
            Console.ReadLine();
        }

        public void printWelcome()
        {
            Console.WriteLine("Paradise Awaits");
            Console.WriteLine("Type 'help' if you get confused or need a command.");
            Console.WriteLine();
            foreach(string line in currentRoom.roomDescription())
            {
                Console.WriteLine(line);
            }
        }

        public Boolean processCommand(Command command)
        {
            Boolean stop = false;
            if (command.commandUnknown())
            {
                Console.WriteLine("That command is unrecognized. Please try again.");
                return false;
            }
            string commandWord = command.getCommandWord();
            if (commandWord.Equals("help"))
            {
                printHelp();
            }
            else if (commandWord.Equals("go"))
            {
                goRoom(command);
            }
            else if (commandWord.Equals("take"))
            {
                takeItem(command);
            }
            else if (commandWord.Equals("drop"))
            {
                dropItem(command);
            }
            else if (commandWord.Equals("inventory"))
            {
                showInventory(command);
            }
            else if (commandWord.Equals("quit"))
            {
                stop = quit(command);
            }
            else if (commandWord.Equals("read"))
            {
                readItem(command);
            }
            else if (commandWord.Equals("light"))
            {
                light(command);
            }
            return stop;
        }

        private void printHelp()
        {
            Console.WriteLine("Your command words are: ");
            parser.showCommands();
        }

        private void light(Command command)
        {
            if(command.hasSecondWord() != true)
            {
                Console.WriteLine("What do you want to light?");
                return;
            }

            string item = command.getSecondWord();

            if (player.inventoryContains(item))
            {
                if (item.Contains("lantern"))
                {
                    Console.WriteLine("With the lantern turned on, you can see into the cave. Proceed NORTH, further into the cave.");
                }
                else
                {
                    Console.WriteLine("You cannot light that.");
                }
            }
            else
            {
                Console.WriteLine("You cannot light something not in your inventory.");
            }
        }

        private void readItem(Command command)
        {
            if(command.hasSecondWord() != true)
            {
                Console.WriteLine("What do you want to read?");
                return;
            }

            string item = command.getSecondWord();

            if (player.inventoryContains(item))
            {
                if (item.Contains("crumpled piece of paper"))
                {
                    Console.WriteLine("The paper reads: \"Welcome to your all-in-one vacation. Paradise awaits no matter what path you choose!\"");
                }
                else if (item.Contains("pamphlet"))
                {
                    Console.WriteLine("The pamphlet reads: \"This lift leads to the top of the mountain, ski at your own risk! Make sure you have the proper equipment with you, you will not be allowed off of the lift without it!\"");
                }
                else
                {
                    Console.WriteLine("You cannot read that.");
                }
            }
            else
            {
                if(item.Contains("warning sign"))
                {
                    Console.WriteLine("The warning sign reads: Warning! Recent bear activity in the area! Proceed with caution.");
                }
                else
                {
                    Console.WriteLine("You cannot read an item not in your inventory.");
                }
            }
        }

        private void goRoom(Command command)
        {
            if(command.hasSecondWord() != true)
            {
                Console.WriteLine("Where do you want to go?");
                return;
            }

            string direction = command.getSecondWord();

            Room nextRoom = currentRoom.getExitRoom(direction);

            if(nextRoom == null)
            {
                Console.WriteLine("You cannot go that way!");
            }
            else
            {
                currentRoom = nextRoom;
                Console.WriteLine();
                foreach (string line in currentRoom.roomDescription())
                {
                    Console.WriteLine(line);
                }
            }
        }

        private void takeItem(Command command)
        {
            if(command.hasSecondWord() != true)
            {
                Console.WriteLine("What do you want to take?");
                return;
            }

            string item = command.getSecondWord();

            if (currentRoom.checkItems(item) == true)
            {
                Console.WriteLine(player.addItem(item));
            }
            else
            {
                Console.WriteLine("That item is not here.");
            }
        }

        private void dropItem(Command command)
        {
            if(command.hasSecondWord() != true)
            {
                Console.WriteLine("What do you want to drop?");
                return;
            }

            string item = command.getSecondWord();

            Console.WriteLine(player.dropItem(item));
        }

        private void showInventory(Command command)
        {
            player.showInventory();
        }

        private Boolean quit(Command command)
        {
            if(command.hasSecondWord() == true)
            {
                Console.WriteLine("Quit what?");
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
