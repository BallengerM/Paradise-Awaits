﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    public class CommandWords
    {
        private static string[] validCommands = { "go", "quit", "help", "take", "drop", "inventory","read","light"};

        public CommandWords()
        {

        }

        public Boolean validCommand(string command)
        {
            for(int i=0; i<validCommands.Length; i++)
            {
                if(validCommands[i].Equals(command))
                {
                    return true;
                }
            }
            return false;
        }

        public void showAll()
        {
            foreach (string command in validCommands)
            {
                Console.Write(command + " ");
            }
            Console.WriteLine();
        }
    }

}
