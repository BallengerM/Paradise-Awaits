﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParadiseAwaits
{
    public class Parser
    {
        private CommandWords commands;
        
        public Parser()
        {
            commands = new CommandWords();
        }


        public Command getCommand()
        {
            string inputLine;
            string word1 = null;
            string word2 = null;

            Console.Write(">> ");

            inputLine = Console.ReadLine();

            string[] words = inputLine.Split(' ');
            word1 = words[0];
            if(words.Length == 2)
            {
                word2 = words[1];
            }
            else if (words.Length > 2)
            {
                for(int i=1; i<words.Length; i++)
                {
                    word2 += words[i];
                    word2 += ' ';
                }
            }

            if (commands.validCommand(word1))
            {
                return new Command(word1, word2);
            }
            else
            {
                return new Command(null, word2);
            }
        }

        public void showCommands()
        {
            commands.showAll();
        }
    }
}
