﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParadiseAwaits;

namespace UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_addItem()
        {
           
        }
    }
}
